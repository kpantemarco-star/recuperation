#include <stdio.h>
#include <math.h>

typedef struct
{
    float abscisse, ordonee;
}Point;

typedef struct 
{
   Point p1; 
   Point p2;
}Droite;

Point lecture(){
    Point p;
    printf("Entrez la valeur de l'abcisse : ");
    scanf("%f", &p.abscisse);
    printf("Entrez la valeur de l'ordonnée : ");
    scanf("%f", &p.ordonee);
    return p;
}
Droite liredroite(){
    Droite d;
    printf("coordonnees du premier point\n");
    d.p1 = lecture();
    printf("Coordonnees du second point\n");
    d.p2 = lecture();
    return d;
}

void AfficheDroite(Droite d){
    printf("Coordonnées du premier point (%.2f ; %.2f)\n", d.p1.abscisse, d.p1.ordonee);
    printf("Coordonnées du premier second (%.2f ; %.2f)\n", d.p2.abscisse, d.p2.ordonee);
}

int Parallele(Droite d1, Droite d2){
    int vecd1, vecd2;
    vecd1 =  (d1.p2.abscisse-d1.p1.abscisse)*(d1.p2.ordonee-d1.p1.ordonee);
    vecd2 =  (d2.p2.abscisse-d2.p1.abscisse)*(d2.p2.ordonee-d2.p1.ordonee);

    if ( vecd1==vecd2)
    {
       return 1;
    }
    return 0;
}

int main(){

    Droite d1, d2; 
    d1 = liredroite();
    AfficheDroite(d1);
    d2 = liredroite();
    AfficheDroite(d2);

    Parallele(d1,d2);
}

